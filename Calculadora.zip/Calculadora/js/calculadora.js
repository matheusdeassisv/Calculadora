var x;
var y;
var operacao;


function inserirNumero(numero){ //função que irá adicionar o número clicado
    document.getElementById("resultado").innerHTML = document.getElementById("resultado").innerHTML + numero;

}

function inserirSinal(sinal){
    sinal = document.getElementById("resultado").innerHTML + sinal;
}

function inserirOperacao(oper) {

    x =   document.getElementById("resultado").innerHTML ;
    operacao = oper;
    limpar();
}

function calcular() {
    y =  document.getElementById("resultado").innerHTML ;
    document.getElementById("resultado").innerHTML = eval(x+operacao+y);

}


function limpar(){ //função que irá limpar o que foi escrito, tudo de uma vez

    document.getElementById("resultado").innerHTML = "";

}


function deletar(){ //funcao que ira deletar o que foi escrito, caracter por caracter 

    let resultado = document.getElementById("resultado").innerHTML;
    document.getElementById("resultado").innerHTML = resultado.substring(0,resultado.length-1);
}